package com.company;

public class M4a1 implements WeaponType{
    @Override
    public void useWeapon() {
        System.out.println("I have M4A1");
    }
}
