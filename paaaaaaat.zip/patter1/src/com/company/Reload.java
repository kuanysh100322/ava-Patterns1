package com.company;

public class Reload implements WeaponBehavior{
    @Override
    public void typeWeapon() {
        System.out.println("I am reloading");
    }
}
