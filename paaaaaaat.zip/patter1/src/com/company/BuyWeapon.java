package com.company;

public class BuyWeapon implements WeaponBehavior{
    @Override
    public void typeWeapon() {
        System.out.println("I am buying");
    }
}
