package com.company;

public class Terrorist extends Character{
    public Terrorist(){
        super(new Move(),new BuyWeapon(), new Ak47());
    }

    @Override
    public void roundStart() {
        System.out.println("Terrorist starts round");
    }
}
