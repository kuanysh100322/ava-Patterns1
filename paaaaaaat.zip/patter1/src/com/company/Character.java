package com.company;

public abstract class Character {
    private MoveBehavior moveBehavior;
    private WeaponBehavior weaponBehavior;
    private WeaponType weaponType;

    public Character(MoveBehavior moveBehavior, WeaponBehavior weaponBehavior,WeaponType weaponType){
        this.moveBehavior = moveBehavior;
        this.weaponBehavior = weaponBehavior;
        this.weaponType = weaponType;
    }

    public void performMove(){
        this.moveBehavior.moveCharacter();
    }
    public void performWeapon(){
        this.weaponBehavior.typeWeapon();
    }
    public void performType(){
        this.weaponType.useWeapon();
    }
    public abstract void roundStart();

    public MoveBehavior getMoveBehavior() {
        return moveBehavior;
    }

    public WeaponBehavior getWeaponBehavior() {
        return weaponBehavior;
    }

    public WeaponType getWeaponType() {
        return weaponType;
    }

    public void setMoveBehavior(MoveBehavior moveBehavior) {
        this.moveBehavior = moveBehavior;
    }

    public void setWeaponBehavior(WeaponBehavior weaponBehavior) {
        this.weaponBehavior = weaponBehavior;
    }

    public void setWeaponType(WeaponType weaponType) {
        this.weaponType = weaponType;
    }
}
