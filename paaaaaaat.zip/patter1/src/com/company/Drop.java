package com.company;

public class Drop implements WeaponBehavior{
    @Override
    public void typeWeapon() {
        System.out.println("I am dropping Weapon");
    }
}
