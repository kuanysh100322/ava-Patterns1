package com.company;

public class Main {
    public static void main(String[] args){
        Terrorist terrorist = new Terrorist();

        terrorist.roundStart();
        terrorist.performWeapon();
        terrorist.performMove();
        terrorist.performType();

        terrorist.setWeaponBehavior(new Drop());
        terrorist.setWeaponType(new Awp());
        terrorist.performWeapon();
        terrorist.performType();

        terrorist.setMoveBehavior(new Sit());
        terrorist.performMove();
        terrorist.setWeaponBehavior(new Shoot());
        terrorist.performWeapon();
        terrorist.setWeaponBehavior(new Reload());
        terrorist.performWeapon();

    }
}
