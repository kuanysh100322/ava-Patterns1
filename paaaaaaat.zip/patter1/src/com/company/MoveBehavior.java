package com.company;

public interface MoveBehavior {
    void moveCharacter();
}
