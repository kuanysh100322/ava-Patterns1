package com.company;

public class Move implements MoveBehavior{
    @Override
    public void moveCharacter() {
        System.out.println("I am moving");
    }
}
