package com.company;

public class Shoot implements WeaponBehavior{
    @Override
    public void typeWeapon() {
        System.out.println("I am shooting");
    }
}
