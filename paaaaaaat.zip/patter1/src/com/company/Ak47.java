package com.company;

public class Ak47 implements WeaponType{
    @Override
    public void useWeapon() {
        System.out.println("I have AK-47");
    }
}
