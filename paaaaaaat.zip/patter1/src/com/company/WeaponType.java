package com.company;

public interface WeaponType {
    void useWeapon();
}
