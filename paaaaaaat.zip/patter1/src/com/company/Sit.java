package com.company;

public class Sit implements MoveBehavior{
    @Override
    public void moveCharacter() {
        System.out.println("I am sitting");
    }
}
