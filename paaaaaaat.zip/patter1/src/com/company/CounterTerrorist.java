package com.company;

public class CounterTerrorist extends Character{
    public CounterTerrorist(){
        super (new Move(), new BuyWeapon(), new M4a1());
    }

    @Override
    public void roundStart() {
        System.out.println("Counter Terrorist starts round");
    }
}
