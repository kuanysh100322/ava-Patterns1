package com.company;

public class Jump implements MoveBehavior{
    @Override
    public void moveCharacter() {
        System.out.println("I am jumping");
    }
}
