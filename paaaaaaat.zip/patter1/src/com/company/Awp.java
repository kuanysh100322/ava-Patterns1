package com.company;

public class Awp implements WeaponType{
    @Override
    public void useWeapon() {
        System.out.println("I have AWP");
    }
}
